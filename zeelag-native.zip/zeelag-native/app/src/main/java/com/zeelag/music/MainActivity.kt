package com.zeelag.music

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay

val Matte = Color(0xFF121212)
val Panel = Color(0xFF1B1B1B)
val Line = Color(0xFF2C2A26)
val Gold = Color(0xFFD8BF8F)
val GoldHi = Color(0xFFF1E0BC)
val GoldDim = Color(0xFF8F7F5E)
val TextC = Color(0xFFECE6D8)

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri) {
    fun toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()
}

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST
    )
    val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000"
    ctx.contentResolver.query(base, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
        val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        while (c.moveToNext()) {
            val id = c.getLong(iId)
            val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
            out += Song(id, c.getString(iTitle) ?: "Untitled", artist, ContentUris.withAppendedId(base, id))
        }
    }
    return out
}

class MainActivity : ComponentActivity() {
    private val controller = mutableStateOf<MediaController?>(null)
    private val songs = mutableStateOf<List<Song>>(emptyList())
    private var future: ListenableFuture<MediaController>? = null

    private val audioPerm =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val askPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private fun hasAudio() =
        ContextCompat.checkSelfPermission(this, audioPerm) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        if (hasAudio()) songs.value = loadSongs(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf(audioPerm)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (hasAudio()) refresh() else askPerms.launch(perms.toTypedArray())
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = Gold, background = Matte, surface = Panel, onSurface = TextC)
            ) {
                Screen(controller.value, songs.value) { refresh() }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({ controller.value = f.get() }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller.value = null
        super.onStop()
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

@Composable
fun Screen(c: MediaController?, songs: List<Song>, onRescan: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var curId by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }

    fun sync(p: Player) {
        playing = p.isPlaying
        title = p.mediaMetadata.title?.toString() ?: ""
        artist = p.mediaMetadata.artist?.toString() ?: ""
        curId = p.currentMediaItem?.mediaId ?: ""
        dur = p.duration.coerceAtLeast(0L)
        shuffle = p.shuffleModeEnabled
        repeat = p.repeatMode
    }

    DisposableEffect(c) {
        val l = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) { sync(player) }
        }
        c?.addListener(l)
        c?.let { sync(it) }
        onDispose { c?.removeListener(l) }
    }
    LaunchedEffect(c) {
        while (true) {
            c?.let { pos = it.currentPosition }
            delay(400)
        }
    }

    val shown = remember(songs, query) {
        if (query.isBlank()) songs
        else songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    }

    Column(Modifier.fillMaxSize().background(Matte).systemBarsPadding()) {
        Text(
            "Zeelag Music", color = Gold, fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold, fontSize = 28.sp,
            modifier = Modifier.padding(20.dp, 16.dp, 20.dp, 8.dp)
        )
        TextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Search songs", color = GoldDim) },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Panel, unfocusedContainerColor = Panel,
                focusedTextColor = TextC, unfocusedTextColor = TextC, cursorColor = Gold,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)
        )
        Spacer(Modifier.height(8.dp))

        if (songs.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No songs found. Allow music access, then scan again.", color = GoldDim)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onRescan,
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Matte)
                ) { Text("Scan music") }
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    val current = curId == s.id.toString()
                    Column(
                        Modifier.fillMaxWidth()
                            .clickable {
                                c?.let {
                                    it.setMediaItems(shown.map { x -> x.toItem() }, i, 0L)
                                    it.prepare()
                                    it.play()
                                }
                            }
                            .padding(horizontal = 20.dp, vertical = 12.dp)
                    ) {
                        Text(
                            s.title, color = if (current) Gold else TextC, fontSize = 16.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            s.artist, color = GoldDim, fontSize = 13.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    HorizontalDivider(color = Line)
                }
            }
        }

        if (title.isNotEmpty() && c != null) {
            Column(Modifier.fillMaxWidth().background(Panel).padding(16.dp, 12.dp)) {
                Text(title, color = TextC, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist, color = GoldDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Slider(
                    value = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                    onValueChange = { f -> if (dur > 0) { pos = (f * dur).toLong(); c.seekTo(pos) } },
                    colors = SliderDefaults.colors(
                        thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Line
                    )
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmt(pos), color = GoldDim, fontSize = 12.sp)
                    Text(fmt(dur), color = GoldDim, fontSize = 12.sp)
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Glyph("⇄", if (shuffle) GoldHi else GoldDim) { c.shuffleModeEnabled = !shuffle }
                    Glyph("⏮", Gold) { c.seekToPreviousMediaItem() }
                    Box(
                        Modifier.size(64.dp).clip(CircleShape).background(Gold)
                            .clickable { if (playing) c.pause() else c.play() },
                        contentAlignment = Alignment.Center
                    ) { Text(if (playing) "⏸" else "▶", color = Matte, fontSize = 26.sp) }
                    Glyph("⏭", Gold) { c.seekToNextMediaItem() }
                    Glyph(
                        if (repeat == Player.REPEAT_MODE_ONE) "↻1" else "↻",
                        if (repeat == Player.REPEAT_MODE_OFF) GoldDim else GoldHi
                    ) {
                        c.repeatMode = when (repeat) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Glyph(t: String, tint: Color, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(t, color = tint, fontSize = 24.sp)
    }
}
